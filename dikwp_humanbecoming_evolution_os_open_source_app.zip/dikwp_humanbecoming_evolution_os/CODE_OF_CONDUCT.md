# Code of Conduct

Be respectful, evidence-oriented, and explicit about uncertainty. Do not promote eugenics, coercion, dehumanization, discriminatory human ranking, or unsupported claims of biological or metaphysical superiority.
