"""Optional Streamlit adapter. The core remains offline and dependency-light."""
from __future__ import annotations
import json
from pathlib import Path
from .analyzer import analyze_file


def run(case_path: str, outdir: str = "outputs/demo") -> dict:
    return analyze_file(Path(case_path), Path(outdir))


def main() -> None:
    try:
        import streamlit as st
    except ImportError as exc:
        raise SystemExit("Install the optional app dependency: pip install -e .[app]") from exc
    st.set_page_config(page_title="DIKWP HumanBecoming Evolution OS", layout="wide")
    st.title("DIKWP HumanBecoming Evolution OS")
    st.caption("Multiscale future-human evolution planning. Not human-worth scoring or clinical augmentation advice.")
    uploaded=st.file_uploader("Upload case JSON", type=["json"])
    if uploaded:
        temp=Path("outputs/streamlit_case.json")
        temp.parent.mkdir(parents=True, exist_ok=True)
        temp.write_bytes(uploaded.getvalue())
        report=analyze_file(temp, "outputs/streamlit")
        st.json(report)

if __name__=="__main__": main()
