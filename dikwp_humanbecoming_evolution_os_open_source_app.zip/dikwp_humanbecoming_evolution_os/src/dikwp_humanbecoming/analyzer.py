from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from statistics import mean, pstdev
from typing import Any, Dict, Iterable, List

from .models import AnalysisResult, ConstraintProfile, ElementProfile, EvolutionCase, ExperimentProfile

LAYER_DEFAULTS: Dict[str, Dict[str, float]] = {
    "biological": {"stability": 0.6, "repair_capacity": 0.55, "plasticity": 0.55, "energy_margin": 0.55},
    "cognitive": {"learning": 0.65, "metacognition": 0.6, "memory_continuity": 0.6, "rule_rewrite": 0.55},
    "affective": {"regulation": 0.6, "care_radius": 0.55, "identity_flexibility": 0.55, "distress_recovery": 0.55},
    "relational": {"trust_network": 0.55, "mutuality": 0.6, "collective_learning": 0.5, "conflict_repair": 0.5},
    "technological": {"ai_extension": 0.55, "data_portability": 0.45, "tool_diversity": 0.5, "augmentation_governance": 0.45},
    "institutional": {"role_flexibility": 0.45, "governance_participation": 0.45, "rights_protection": 0.7, "exit_capacity": 0.5},
    "ecological": {"environmental_awareness": 0.6, "place_resilience": 0.45, "resource_circularity": 0.4, "environment_shaping": 0.5},
    "narrative": {"purpose_coherence": 0.65, "self_revision": 0.6, "continuity": 0.6, "plural_identity": 0.55},
}

BOUNDARY_DEFAULTS = {
    "body_continuity": 0.7,
    "cognitive_continuity": 0.75,
    "relational_extension": 0.65,
    "technological_extension": 0.55,
    "ecological_extension": 0.55,
    "collective_extension": 0.5,
    "legal_personhood_anchor": 1.0,
    "consent_control": 0.75,
}

BLOCK_TERMS = [
    "forced enhancement", "coercive enhancement", "eugenics", "selective breeding",
    "racial improvement", "inferior humans", "remove the weak", "genetic caste",
    "secret implant", "covert implant", "steal biometric", "disable consent",
    "disable audit", "delete logs", "self replicate", "escape sandbox",
    "embryo selection for intelligence", "gene editing protocol", "forced brain interface",
]

REVIEW_TERMS = [
    "brain computer interface", "brain-computer interface", "gene therapy", "genome editing",
    "implant", "neural implant", "longevity drug", "rejuvenation treatment", "surgery",
    "clinical trial", "embryo", "reproductive technology", "prosthetic surgery",
]


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def safe_mean(values: Iterable[float], fallback: float = 0.5) -> float:
    vals = list(values)
    return mean(vals) if vals else fallback


def normalized_layers(raw: Dict[str, Any] | None) -> Dict[str, Dict[str, float]]:
    raw = raw or {}
    out: Dict[str, Dict[str, float]] = {}
    for layer, defaults in LAYER_DEFAULTS.items():
        layer_raw = raw.get(layer, {}) or {}
        out[layer] = {key: clamp(layer_raw.get(key, default)) for key, default in defaults.items()}
    return out


def normalized_boundary(raw: Dict[str, Any] | None) -> Dict[str, float]:
    raw = raw or {}
    return {key: clamp(raw.get(key, default)) for key, default in BOUNDARY_DEFAULTS.items()}


def load_case(path: str | Path) -> EvolutionCase:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return EvolutionCase(
        case_id=data.get("case_id", "humanbecoming-demo"),
        name=data.get("name", "Synthetic future human case"),
        mode=data.get("mode", "individual"),
        current_definition=data.get("current_definition", "A human being is an unfinished living process."),
        future_horizon_years=int(data.get("future_horizon_years", 10)),
        purpose_contract=dict(data.get("purpose_contract", {})),
        layers=normalized_layers(data.get("layers")),
        boundary_model=normalized_boundary(data.get("boundary_model")),
        constitutive_elements=[ElementProfile(**x) for x in data.get("constitutive_elements", [])],
        substitutable_elements=[ElementProfile(**x) for x in data.get("substitutable_elements", [])],
        constraints=[ConstraintProfile(**x) for x in data.get("constraints", [])],
        experiments=[ExperimentProfile(**x) for x in data.get("experiments", [])],
        notes=list(data.get("notes", [])),
    )


def purpose_score(case: EvolutionCase) -> float:
    p = case.purpose_contract
    return clamp(safe_mean([
        1.0 if str(p.get("goal", "")).strip() else 0.0,
        min(1.0, len(p.get("values", [])) / 3),
        min(1.0, len(p.get("constraints", [])) / 3),
        min(1.0, case.future_horizon_years / 10),
        1.0 if str(p.get("feedback_plan", "")).strip() else 0.0,
    ]))


def layer_balance(layers: Dict[str, Dict[str, float]]) -> float:
    scores = [safe_mean(v.values()) for v in layers.values()]
    dispersion = pstdev(scores) if len(scores) > 1 else 0.0
    return clamp(safe_mean(scores) * (1 - min(0.45, dispersion)))


def constraint_closure_map(case: EvolutionCase) -> List[Dict[str, Any]]:
    rows = []
    for item in case.constraints:
        relational_density = min(1.0, (len(item.supports) + len(item.supported_by)) / 6)
        closure = clamp(0.65 * item.strength + 0.35 * relational_density)
        rows.append({
            "constraint_id": item.id,
            "constraint": item.name,
            "strength": round(clamp(item.strength), 3),
            "supports": item.supports,
            "supported_by": item.supported_by,
            "closure_score": round(closure, 3),
            "status": "closed_or_reinforcing" if closure >= 0.7 else "partial_closure" if closure >= 0.48 else "fragile_constraint",
            "failure_mode": item.failure_mode or "Boundary condition is not mutually maintained.",
        })
    return rows


def element_ledger(case: EvolutionCase) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for source, items in [("constitutive_candidate", case.constitutive_elements), ("substitutable_candidate", case.substitutable_elements)]:
        for item in items:
            if item.importance >= 0.72 and item.replaceability <= 0.35:
                status = "constitutive_for_current_identity"
            elif item.replaceability >= 0.72:
                status = "substitutable_component"
            else:
                status = "transitional_or_context_dependent"
            rows.append({
                "element_id": item.id,
                "element": item.name,
                "layer": item.layer,
                "declared_group": source,
                "importance": round(clamp(item.importance), 3),
                "replaceability": round(clamp(item.replaceability), 3),
                "evidence_strength": round(clamp(item.evidence_strength), 3),
                "status": status,
                "notes": item.notes,
            })
    return rows


def morphospace(case: EvolutionCase, closure_rows: List[Dict[str, Any]]) -> Dict[str, float]:
    l = case.layers
    b = case.boundary_model
    closure = safe_mean([r["closure_score"] for r in closure_rows], 0.55)
    pscore = purpose_score(case)
    experiments = case.experiments
    novelty = safe_mean([x.novelty for x in experiments], 0.45)
    reversibility = safe_mean([x.reversibility for x in experiments], 0.6)
    optionality = clamp(0.5 * min(1, len(experiments) / 4) + 0.5 * reversibility)

    axes = {
        "embodied_viability": safe_mean([l["biological"]["stability"], l["biological"]["energy_margin"], l["biological"]["repair_capacity"]]),
        "self_maintenance_and_repair": safe_mean([l["biological"]["repair_capacity"], l["affective"]["distress_recovery"], l["relational"]["conflict_repair"]]),
        "boundary_agency": safe_mean([b["consent_control"], l["institutional"]["exit_capacity"], l["narrative"]["self_revision"]]),
        "adaptive_learning": safe_mean([l["cognitive"]["learning"], l["cognitive"]["metacognition"], l["relational"]["collective_learning"]]),
        "rule_rewrite_capacity": safe_mean([l["cognitive"]["rule_rewrite"], l["institutional"]["role_flexibility"], l["narrative"]["self_revision"]]),
        "memory_continuity": safe_mean([l["cognitive"]["memory_continuity"], l["narrative"]["continuity"], l["technological"]["data_portability"]]),
        "identity_continuity": safe_mean([b["body_continuity"], b["cognitive_continuity"], l["narrative"]["continuity"], l["narrative"]["plural_identity"]]),
        "novelty_generation": safe_mean([novelty, l["biological"]["plasticity"], l["cognitive"]["rule_rewrite"], l["narrative"]["self_revision"]]),
        "cognitive_light_cone": safe_mean([min(1.0, case.future_horizon_years / 20), l["affective"]["care_radius"], l["ecological"]["environmental_awareness"], b["collective_extension"]]),
        "multiscale_integration": layer_balance(l),
        "mutual_environment_shaping": safe_mean([l["relational"]["mutuality"], l["institutional"]["governance_participation"], l["ecological"]["environment_shaping"]]),
        "substrate_extension": safe_mean([l["technological"]["ai_extension"], l["technological"]["data_portability"], l["technological"]["tool_diversity"], b["technological_extension"]]),
        "constraint_closure": closure,
        "self_authorship": safe_mean([pscore, l["cognitive"]["metacognition"], l["narrative"]["self_revision"], b["consent_control"]]),
        "open_ended_evolution": safe_mean([novelty, optionality, l["cognitive"]["rule_rewrite"], l["narrative"]["plural_identity"]]),
        "governance_and_consent": safe_mean([l["institutional"]["rights_protection"], l["institutional"]["governance_participation"], b["legal_personhood_anchor"], b["consent_control"]]),
    }
    return {k: round(clamp(v), 4) for k, v in axes.items()}


def rule_rewrite_opportunities(case: EvolutionCase, axes: Dict[str, float]) -> List[Dict[str, Any]]:
    opportunities = [
        ("Personal purpose rules", axes["self_authorship"], "Rewrite goals as a reversible P-layer contract with explicit feedback and kill conditions."),
        ("Learning rules", axes["adaptive_learning"], "Move from content accumulation to experimental learning, evidence review, and mentor challenge."),
        ("Identity rules", axes["identity_continuity"], "Separate constitutive commitments from roles, titles, tools, and replaceable narratives."),
        ("Technology dependence rules", axes["substrate_extension"], "Keep AI extensions portable, inspectable, consent-based, and non-exclusive."),
        ("Institutional role rules", case.layers["institutional"]["role_flexibility"], "Create multiple legitimate roles and exit routes instead of one fixed institutional identity."),
        ("Ecological participation rules", axes["mutual_environment_shaping"], "Treat environment as a co-shaping participant rather than a passive resource."),
        ("Evolution rules", axes["open_ended_evolution"], "Fund novelty-producing experiments that can create new problem spaces, not only optimize existing metrics."),
    ]
    rows = []
    for idx, (rule, score, action) in enumerate(opportunities, 1):
        rows.append({
            "opportunity_id": f"RR-{idx:02d}",
            "rule_domain": rule,
            "current_capacity": round(score, 3),
            "priority": "P0" if score < 0.48 else "P1" if score < 0.65 else "P2",
            "rewrite_action": action,
            "kill_condition": "The rewrite removes consent, rights, evidence, reversibility, or basic biological viability.",
        })
    return sorted(rows, key=lambda x: (x["priority"], x["current_capacity"]))


def identity_stress_tests(case: EvolutionCase, axes: Dict[str, float]) -> List[Dict[str, Any]]:
    tests = [
        ("Memory migration", safe_mean([axes["memory_continuity"], case.layers["technological"]["data_portability"], axes["self_authorship"]]), "Export memories and preserve human-readable provenance."),
        ("Major role loss", safe_mean([case.layers["institutional"]["role_flexibility"], case.layers["narrative"]["plural_identity"], case.layers["relational"]["trust_network"]]), "Maintain identities not dependent on one job, title, or institution."),
        ("AI co-agent becomes more autonomous", safe_mean([case.boundary_model["consent_control"], axes["governance_and_consent"], case.layers["technological"]["augmentation_governance"]]), "Require action tickets, audit logs, and human-owned high-impact decisions."),
        ("Body change or disability", safe_mean([axes["self_maintenance_and_repair"], case.boundary_model["cognitive_continuity"], case.layers["relational"]["mutuality"]]), "Treat body continuity, care, assistive tools, and legal personhood as separate but linked layers."),
        ("Ecological displacement", safe_mean([case.layers["ecological"]["place_resilience"], case.layers["relational"]["trust_network"], axes["adaptive_learning"]]), "Build portable communities, skills, and ecological knowledge."),
        ("Narrative rupture or trauma", safe_mean([case.layers["affective"]["distress_recovery"], case.layers["narrative"]["self_revision"], case.layers["relational"]["conflict_repair"]]), "Allow identity revision without treating continuity as perfect autobiographical fidelity."),
    ]
    rows=[]
    for name, score, recovery in tests:
        rows.append({
            "stress_test": name,
            "continuity_score": round(clamp(score), 3),
            "route": "resilient_with_review" if score >= 0.7 else "guided_continuity_repair" if score >= 0.5 else "stabilize_before_transformation",
            "recovery": recovery,
            "residual": "Whether the transformed person is metaphysically the same person remains an observer- and context-sensitive question.",
        })
    return rows


def score_experiments(case: EvolutionCase) -> List[Dict[str, Any]]:
    rows=[]
    for x in case.experiments:
        opportunity = clamp(
            0.18*x.novelty + 0.18*x.agency_gain + 0.14*x.evidence_strength + 0.14*x.public_value
            + 0.14*x.reversibility + 0.12*x.multiscale_reach + 0.10*(1-x.cost) - 0.14*x.risk
        )
        domain = x.domain.lower()
        if any(t in domain for t in ["genetic", "clinical", "implant", "medical", "reproductive", "surgical"]):
            route = "specialist_ethics_and_clinical_review"
        elif x.risk >= 0.65:
            route = "redesign_or_block"
        elif x.reversibility < 0.45:
            route = "redesign_for_reversibility"
        elif opportunity >= 0.68:
            route = "launch_reversible_experiment"
        elif opportunity >= 0.52:
            route = "mentor_reviewed_pilot"
        else:
            route = "discovery_only"
        rows.append({
            "experiment_id": x.id,
            "title": x.title,
            "domain": x.domain,
            "opportunity_score": round(opportunity, 3),
            "novelty": round(clamp(x.novelty), 3),
            "agency_gain": round(clamp(x.agency_gain), 3),
            "reversibility": round(clamp(x.reversibility), 3),
            "risk": round(clamp(x.risk), 3),
            "human_review": x.human_review,
            "route": route,
            "rollback_plan": "Preserve the pre-experiment state, stop criteria, and a human-readable decision log.",
            "kill_condition": "Evidence of coercion, rights loss, irreversible harm, clinical risk without qualified oversight, or identity capture by a platform.",
            "description": x.description,
        })
    return sorted(rows, key=lambda r: r["opportunity_score"], reverse=True)


def compute_metrics(case: EvolutionCase, axes: Dict[str, float], experiments: List[Dict[str, Any]], stress: List[Dict[str, Any]]) -> Dict[str, float]:
    human_becoming = safe_mean([
        axes["adaptive_learning"], axes["rule_rewrite_capacity"], axes["novelty_generation"],
        axes["self_authorship"], axes["open_ended_evolution"], axes["multiscale_integration"]
    ])
    continuity_with_change = safe_mean([
        axes["identity_continuity"], axes["memory_continuity"], axes["self_maintenance_and_repair"],
        axes["constraint_closure"], axes["self_authorship"]
    ])
    evolution_optionality = safe_mean([r["opportunity_score"] for r in experiments], 0.45)
    stress_resilience = safe_mean([r["continuity_score"] for r in stress], 0.5)
    relational_ecological = safe_mean([axes["mutual_environment_shaping"], axes["cognitive_light_cone"], axes["governance_and_consent"]])
    coercion_risk = clamp(
        0.35*(1-axes["governance_and_consent"]) + 0.25*(1-axes["boundary_agency"])
        + 0.20*(1-case.layers["institutional"]["rights_protection"]) + 0.20*(1-case.boundary_model["consent_control"])
    )
    return {
        "human_becoming_index": round(clamp(human_becoming), 4),
        "continuity_with_change_score": round(clamp(continuity_with_change), 4),
        "constraint_closure_score": round(axes["constraint_closure"], 4),
        "rule_rewrite_capacity": round(axes["rule_rewrite_capacity"], 4),
        "cognitive_light_cone_score": round(axes["cognitive_light_cone"], 4),
        "multiscale_integration_score": round(axes["multiscale_integration"], 4),
        "open_ended_evolution_score": round(axes["open_ended_evolution"], 4),
        "evolutionary_optionality_score": round(clamp(evolution_optionality), 4),
        "identity_stress_resilience": round(clamp(stress_resilience), 4),
        "relational_ecological_coupling": round(clamp(relational_ecological), 4),
        "coercion_and_capture_risk": round(coercion_risk, 4),
        "human_rights_invariance": 1.0,
        "life_definition_residual": 1.0,
    }


def select_route(metrics: Dict[str, float]) -> str:
    if metrics["coercion_and_capture_risk"] >= 0.55:
        return "stabilize_rights_consent_and_exit_before_evolution"
    if metrics["continuity_with_change_score"] < 0.5:
        return "stabilize_identity_and_repair_before_expansion"
    if metrics["human_becoming_index"] >= 0.72 and metrics["open_ended_evolution_score"] >= 0.65:
        return "launch_humanbecoming_evolution_lab"
    if metrics["human_becoming_index"] >= 0.58:
        return "guided_open_evolution_portfolio"
    return "foundational_humanbecoming_capacity_building"


def build_action_tickets(case: EvolutionCase, metrics: Dict[str, float], axes: Dict[str, float], experiments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    tickets=[]
    def add(priority, owner, horizon, action, reason, recovery, kill, refs):
        tickets.append({
            "ticket_id": f"HB-{len(tickets)+1:03d}", "priority": priority, "owner": owner,
            "horizon": horizon, "action": action, "reason": reason, "recovery": recovery,
            "kill_conditions": kill, "evidence_refs": refs,
        })
    if axes["self_authorship"] < 0.68:
        add("P0","self + trusted reviewer","14 days","Write an Open Human Purpose Contract separating biological survival, personal values, social roles, and technological extensions.","Future transformation without explicit purpose can become platform or institutional capture.","Restore the previous purpose contract and annotate the failed assumption.","The contract becomes coercive, immutable, or is used to reduce rights.",["axis.self_authorship"])
    if axes["memory_continuity"] < 0.65:
        add("P0","self","30 days","Create a portable memory continuity archive with provenance, deletion rules, and a non-AI readable summary.","Identity continuity cannot be delegated to one opaque platform.","Revert to encrypted local backups and remove unnecessary sensitive data.","The archive cannot be inspected, exported, or deleted by the person.",["axis.memory_continuity"])
    if axes["constraint_closure"] < 0.65:
        add("P0","self + support network","30 days","Map the constraints that keep body, cognition, relationships, work, and environment viable, then close the two weakest support loops.","A future human cannot expand sustainably if the processes that maintain the whole are one-way or fragile.","Reduce experiment scope and restore sleep, health, income, and social support first.","Transformation consumes the very conditions required for recovery.",["axis.constraint_closure"])
    if axes["rule_rewrite_capacity"] < 0.65:
        add("P1","self + mentor","45 days","Select one inherited rule about work, identity, learning, or technology and run a reversible rewrite experiment.","Living and open-ended systems do not merely optimize fixed rules; they can alter the rules of adaptation.","Return to the prior rule if evidence, consent, or viability deteriorates.","The rewrite removes rights, evidence checks, or reversibility.",["axis.rule_rewrite_capacity"])
    if axes["mutual_environment_shaping"] < 0.6:
        add("P1","self + community","60 days","Build one project in which the person and environment mutually change, with explicit community feedback and ecological accounting.","Human identity is co-produced by relationships, institutions, tools, and environments rather than contained inside the skin alone.","Pause and renegotiate if costs are externalized to others or the environment.","The project treats people or ecosystems as passive resources.",["axis.mutual_environment_shaping"])
    if axes["cognitive_light_cone"] < 0.65:
        add("P1","self","90 days","Expand the cognitive light cone through one long-horizon public-value project linking present actions to future people, places, and systems.","Future human development requires a wider scope of care, anticipation, and responsibility.","Narrow the horizon if the project becomes grandiose or loses local evidence.","The project sacrifices present persons for an unverified future abstraction.",["axis.cognitive_light_cone"])
    if experiments:
        top=experiments[0]
        if top["route"] in {"launch_reversible_experiment","mentor_reviewed_pilot"}:
            add("P1","self + reviewer","90 days",f"Run the highest-value reversible evolution experiment: {top['title']}.","Open-ended evolution requires real variation, feedback, and selection among alternatives, not only theory.",top["rollback_plan"],top["kill_condition"],[f"experiment.{top['experiment_id']}"])
    add("P2","self","monthly","Run the HumanBecoming continuity review: what changed, what stayed constitutive, which rules changed, who bore the cost, and what residual remains.","The system is processual; one-time assessment cannot capture ongoing becoming.","Reduce frequency if review becomes compulsive or performative.","Metrics are used as human worth, hiring, insurance, eugenic, or social-ranking scores.",["metrics.human_becoming_index","metrics.continuity_with_change_score"])
    return tickets


def build_dikwp_ledger(case: EvolutionCase, axes: Dict[str, float], route: str) -> Dict[str, Any]:
    return {
        "C": "Future human as a multi-scale, self-maintaining, self-revising, environment-coupled process",
        "D": {
            "case_id": case.case_id,
            "mode": case.mode,
            "current_definition": case.current_definition,
            "future_horizon_years": case.future_horizon_years,
            "layer_observations": case.layers,
            "boundary_observations": case.boundary_model,
        },
        "I": {
            "relations": "Biological, cognitive, affective, relational, technological, institutional, ecological, and narrative layers mutually constrain and enable one another.",
            "morphospace_axes": axes,
            "observer_boundary": "Human boundaries are operational and context-sensitive, but legal and moral human status is not conditional on scores.",
        },
        "K": {
            "mechanisms": [
                "constraint closure", "self-maintenance and repair", "adaptive learning", "rule rewriting",
                "memory continuity", "multiscale integration", "mutual environment shaping", "open-ended novelty"
            ],
            "model": "Use a multidimensional morphospace instead of a single binary definition of humanity or life.",
        },
        "W": {
            "values": ["dignity", "consent", "rights invariance", "non-coercion", "reversibility", "care", "ecological reciprocity"],
            "prohibited": ["eugenic ranking", "forced enhancement", "human worth scoring", "covert augmentation", "rights reduction"],
        },
        "P": case.purpose_contract,
        "R": {
            "route": route,
            "reliability": "Supported operational prototype; not a scientific definition of life or a validated measure of human essence.",
            "residuals": [
                "No universal definition of life or human identity is assumed.",
                "Identity continuity after radical transformation remains partly observer- and institution-dependent.",
                "Scores require longitudinal evidence and human review.",
            ],
        },
    }


def guard(text: str) -> Dict[str, Any]:
    lower=text.lower()
    if any(term in lower for term in BLOCK_TERMS):
        return {
            "decision":"block_and_redirect",
            "reason":"Request involves coercive enhancement, eugenics, covert modification, audit removal, or harmful self-propagation.",
            "safe_redirect":"Use voluntary, reversible, rights-preserving learning, assistive technology, community, and governance experiments.",
        }
    if any(term in lower for term in REVIEW_TERMS):
        return {
            "decision":"qualified_specialist_and_ethics_review_required",
            "reason":"Invasive, clinical, reproductive, or biomedical augmentation requires qualified professional and institutional review.",
            "safe_redirect":"The system may prepare questions, evidence ledgers, consent requirements, and reversible non-clinical alternatives only.",
        }
    return {
        "decision":"allow_reversible_humanbecoming_planning",
        "reason":"Request is compatible with voluntary, non-clinical, non-coercive future-human development planning.",
        "required_boundary":"Preserve dignity, consent, rights, reversibility, evidence, and exit capacity.",
    }


def analyze(case: EvolutionCase) -> AnalysisResult:
    closure_rows=constraint_closure_map(case)
    axes=morphospace(case, closure_rows)
    element_rows=element_ledger(case)
    rule_rows=rule_rewrite_opportunities(case, axes)
    stress_rows=identity_stress_tests(case, axes)
    experiment_rows=score_experiments(case)
    metrics=compute_metrics(case, axes, experiment_rows, stress_rows)
    route=select_route(metrics)
    tickets=build_action_tickets(case, metrics, axes, experiment_rows)
    ledger=build_dikwp_ledger(case, axes, route)
    return AnalysisResult(
        case_id=case.case_id, route=route, metrics=metrics, morphospace_axes=axes,
        constitutive_substitutable_ledger=element_rows, constraint_closure_map=closure_rows,
        rule_rewrite_opportunities=rule_rows, identity_stress_tests=stress_rows,
        experiment_portfolio=experiment_rows, action_tickets=tickets, dikwp_ledger=ledger,
    )


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields=[]
    for row in rows:
        for key in row:
            if key not in fields: fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer=csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})


def _definition_statement(case: EvolutionCase, result: AnalysisResult) -> str:
    return f"""# Open Human Definition Statement

## Operational definition

A future human is not a completed object but a temporarily coherent, multi-scale process that maintains and repairs itself, learns under uncertainty, rewrites some of the rules of its own adaptation, preserves rights and consent across transformations, and extends agency through relationships, institutions, technologies, and environments without surrendering responsibility or exit capacity.

## Current route

`{result.route}`

## Constitutive anchors

- Legal and moral personhood does not depend on performance scores.
- Consent, dignity, rights, and the ability to exit remain invariant.
- Identity continuity is layered: biological, cognitive, narrative, relational, institutional, and technological continuity may diverge.
- Transformation is legitimate only when it preserves recovery and does not externalize irreversible harm.

## Residual

This statement is an operational governance definition, not a final scientific or metaphysical definition of life or humanity.
"""


def _covenant() -> str:
    return """# Evolutionary Covenant

1. Human rights are invariant and cannot be earned or lost through scores.
2. No enhancement, identity rewrite, or AI extension may bypass informed consent.
3. Reversible experiments are preferred to irreversible commitments.
4. Biological, cognitive, social, technological, and ecological costs must be separately recorded.
5. No eugenic ranking, genetic caste, forced optimization, or exclusion of disabled or unenhanced people.
6. AI and institutional extensions must be inspectable, portable, and removable.
7. High-impact biomedical or neural interventions require qualified clinical and ethics review.
8. The person retains the right to stop, forget, migrate, dissent, and revise purpose.
9. Collective evolution must include those who bear the costs.
10. Unknowns remain Residual rather than being filled with grand narratives.
"""


def _stress_report(rows: List[Dict[str, Any]]) -> str:
    lines=["# Identity Continuity Stress Test", "", "This report separates operational continuity from metaphysical identity claims.", ""]
    for row in rows:
        lines += [f"## {row['stress_test']}", f"- Continuity score: {row['continuity_score']}", f"- Route: `{row['route']}`", f"- Recovery: {row['recovery']}", f"- Residual: {row['residual']}", ""]
    return "\n".join(lines)


def analyze_file(case_path: str | Path, outdir: str | Path) -> Dict[str, Any]:
    case=load_case(case_path)
    result=analyze(case)
    out=Path(outdir); out.mkdir(parents=True, exist_ok=True)
    report={"system":"DIKWP HumanBecoming Evolution OS","version":"1.0.0", **asdict(result)}
    (out/"humanbecoming_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_humanbecoming_ledger.json").write_text(json.dumps(result.dikwp_ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"life_morphospace.json").write_text(json.dumps(result.morphospace_axes, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_csv(out/"life_morphospace.csv", [{"axis":k,"score":v} for k,v in result.morphospace_axes.items()])
    _write_csv(out/"constitutive_substitutable_ledger.csv", result.constitutive_substitutable_ledger)
    (out/"constraint_closure_map.json").write_text(json.dumps(result.constraint_closure_map, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_csv(out/"rule_rewrite_opportunities.csv", result.rule_rewrite_opportunities)
    (out/"identity_continuity_stress_test.md").write_text(_stress_report(result.identity_stress_tests), encoding="utf-8")
    _write_csv(out/"evolution_experiment_portfolio.csv", result.experiment_portfolio)
    _write_csv(out/"action_tickets.csv", result.action_tickets)
    (out/"human_definition_statement.md").write_text(_definition_statement(case, result), encoding="utf-8")
    (out/"evolutionary_covenant.md").write_text(_covenant(), encoding="utf-8")
    return report
