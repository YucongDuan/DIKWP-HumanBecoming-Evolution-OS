from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class ElementProfile:
    id: str
    name: str
    layer: str
    importance: float = 0.5
    replaceability: float = 0.5
    evidence_strength: float = 0.5
    notes: str = ""


@dataclass
class ConstraintProfile:
    id: str
    name: str
    strength: float = 0.5
    supports: List[str] = field(default_factory=list)
    supported_by: List[str] = field(default_factory=list)
    failure_mode: str = ""


@dataclass
class ExperimentProfile:
    id: str
    title: str
    domain: str
    novelty: float = 0.5
    agency_gain: float = 0.5
    evidence_strength: float = 0.4
    public_value: float = 0.5
    reversibility: float = 0.7
    multiscale_reach: float = 0.5
    cost: float = 0.3
    risk: float = 0.3
    human_review: bool = True
    description: str = ""


@dataclass
class EvolutionCase:
    case_id: str
    name: str
    mode: str
    current_definition: str
    future_horizon_years: int
    purpose_contract: Dict[str, Any]
    layers: Dict[str, Dict[str, float]]
    boundary_model: Dict[str, float]
    constitutive_elements: List[ElementProfile] = field(default_factory=list)
    substitutable_elements: List[ElementProfile] = field(default_factory=list)
    constraints: List[ConstraintProfile] = field(default_factory=list)
    experiments: List[ExperimentProfile] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


@dataclass
class AnalysisResult:
    case_id: str
    route: str
    metrics: Dict[str, float]
    morphospace_axes: Dict[str, float]
    constitutive_substitutable_ledger: List[Dict[str, Any]]
    constraint_closure_map: List[Dict[str, Any]]
    rule_rewrite_opportunities: List[Dict[str, Any]]
    identity_stress_tests: List[Dict[str, Any]]
    experiment_portfolio: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    dikwp_ledger: Dict[str, Any]
