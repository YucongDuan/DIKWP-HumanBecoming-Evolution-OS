from __future__ import annotations

import argparse
import json

from .analyzer import analyze_file, guard
from .static_audit import write_audit


def main(argv=None) -> None:
    parser=argparse.ArgumentParser(prog="humanbecoming")
    sub=parser.add_subparsers(dest="command", required=True)
    p=sub.add_parser("analyze", help="Analyze a future-human evolution case JSON.")
    p.add_argument("case")
    p.add_argument("--out", default="outputs/demo")
    g=sub.add_parser("guard", help="Check a proposed evolution or augmentation request.")
    g.add_argument("text")
    a=sub.add_parser("static-audit", help="Audit the offline core source tree.")
    a.add_argument("root")
    a.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args=parser.parse_args(argv)
    if args.command=="analyze": print(json.dumps(analyze_file(args.case,args.out),ensure_ascii=False,indent=2))
    elif args.command=="guard": print(json.dumps(guard(args.text),ensure_ascii=False,indent=2))
    else: print(json.dumps(write_audit(args.root,args.out),ensure_ascii=False,indent=2))

if __name__=="__main__": main()
