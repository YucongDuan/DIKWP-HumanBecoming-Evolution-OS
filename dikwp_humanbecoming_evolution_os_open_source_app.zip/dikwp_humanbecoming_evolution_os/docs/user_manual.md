# User Manual

## 浏览器模式

1. 打开根目录 `index.html`。
2. 选择一个合成场景。
3. 调整八层状态和边界参数。
4. 查看十六轴形态空间。
5. 检查构成性—可替换性账本。
6. 运行身份连续性压力测试。
7. 选择可逆演化实验。
8. 导出 JSON 和行动票据。

## CLI 模式

```bash
pip install -e .
humanbecoming analyze examples/sample_humanbecoming_case.json --out outputs/demo
humanbecoming guard "build a reversible AI memory portability experiment"
humanbecoming static-audit src --out outputs/demo/static_boundary_audit_report.json
```

## 解释分数

分数只描述当前输入下的运行状态。不要用于比较人的价值。低分可能是缺数据、当前目的不相关、真实瓶颈或制度压制，需要结合上下文判断。
