# Roadmap

## v1.1

- longitudinal profiles and versioned identity ledgers
- interactive network visualization of constraint closure
- comparison of multiple future states without ranking people

## v1.2

- institution and community participatory mode
- multilingual terminology integrity layer
- external evidence connectors with provenance

## v2.0

- simulation of multiscale human-AI collectives
- governance of collective personhood and shared memory
- independent academic validation studies
- accessibility-first interfaces
