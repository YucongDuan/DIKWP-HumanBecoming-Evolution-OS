# Source Synthesis

Primary attachment:

- Kofman, K. et al. (2026). "Defining Life: A Conversation." Organisms: Journal of Biological Sciences, 9(1), 11–45. DOI: 10.13133/2532-5876/19492. CC-BY.

Key conceptual sources cited in that paper and used as design inspiration:

- Bender, Kofman, Agüera y Arcas & Levin (2025), *What Lives?*
- Montévil & Mossio (2015), constraint closure.
- Kauffman & Roli (2023), open-ended evolution and a third transition in science.
- Buckley et al. (2024), natural induction and spontaneous adaptive organisation.
- McMillen & Levin (2024), collective intelligence across scales and substrates.
- Stepney (2023), life as a cyber-bio-physical system with changing state spaces and meta-dynamics.
- Blackiston et al. (2021), synthetic living machines.

Design stance:

The software extracts operational questions from these debates. It does not claim that any one theory has been experimentally established as the definition of life or humanity.
