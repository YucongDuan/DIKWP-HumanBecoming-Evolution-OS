# Security Policy

The reference core is offline. Do not add credential collection, hidden telemetry, remote code execution, browser automation, host mutation, or autonomous external action without a separate reviewed adapter.

Report vulnerabilities through the repository's private security channel.
