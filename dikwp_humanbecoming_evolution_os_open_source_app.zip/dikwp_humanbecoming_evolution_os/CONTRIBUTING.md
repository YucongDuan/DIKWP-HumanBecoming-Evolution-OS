# Contributing

Contributions are welcome when they preserve human rights invariance, consent, reversibility, evidence custody, and the non-ranking design.

Please include tests, document any new metric, state its failure modes, and avoid claims that the score measures a person's essence or worth.
