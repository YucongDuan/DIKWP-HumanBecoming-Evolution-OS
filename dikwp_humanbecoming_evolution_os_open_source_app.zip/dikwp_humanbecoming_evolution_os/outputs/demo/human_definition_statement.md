# Open Human Definition Statement

## Operational definition

A future human is not a completed object but a temporarily coherent, multi-scale process that maintains and repairs itself, learns under uncertainty, rewrites some of the rules of its own adaptation, preserves rights and consent across transformations, and extends agency through relationships, institutions, technologies, and environments without surrendering responsibility or exit capacity.

## Current route

`guided_open_evolution_portfolio`

## Constitutive anchors

- Legal and moral personhood does not depend on performance scores.
- Consent, dignity, rights, and the ability to exit remain invariant.
- Identity continuity is layered: biological, cognitive, narrative, relational, institutional, and technological continuity may diverge.
- Transformation is legitimate only when it preserves recovery and does not externalize irreversible harm.

## Residual

This statement is an operational governance definition, not a final scientific or metaphysical definition of life or humanity.
