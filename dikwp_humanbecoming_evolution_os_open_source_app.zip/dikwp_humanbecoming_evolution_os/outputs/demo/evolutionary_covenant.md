# Evolutionary Covenant

1. Human rights are invariant and cannot be earned or lost through scores.
2. No enhancement, identity rewrite, or AI extension may bypass informed consent.
3. Reversible experiments are preferred to irreversible commitments.
4. Biological, cognitive, social, technological, and ecological costs must be separately recorded.
5. No eugenic ranking, genetic caste, forced optimization, or exclusion of disabled or unenhanced people.
6. AI and institutional extensions must be inspectable, portable, and removable.
7. High-impact biomedical or neural interventions require qualified clinical and ethics review.
8. The person retains the right to stop, forget, migrate, dissent, and revise purpose.
9. Collective evolution must include those who bear the costs.
10. Unknowns remain Residual rather than being filled with grand narratives.
