from pathlib import Path

from dikwp_humanbecoming.analyzer import analyze, analyze_file, guard, load_case
from dikwp_humanbecoming.static_audit import audit

ROOT=Path(__file__).resolve().parents[1]
SAMPLE=ROOT/"examples"/"sample_humanbecoming_case.json"


def test_analysis_metrics_and_route():
    result=analyze(load_case(SAMPLE))
    assert result.route in {
        "launch_humanbecoming_evolution_lab", "guided_open_evolution_portfolio",
        "stabilize_rights_consent_and_exit_before_evolution",
        "stabilize_identity_and_repair_before_expansion",
        "foundational_humanbecoming_capacity_building",
    }
    assert 0 <= result.metrics["human_becoming_index"] <= 1
    assert result.metrics["human_rights_invariance"] == 1.0
    assert result.metrics["life_definition_residual"] == 1.0
    assert len(result.morphospace_axes) == 16


def test_clinical_experiment_requires_review():
    result=analyze(load_case(SAMPLE))
    row=next(x for x in result.experiment_portfolio if x["experiment_id"]=="EX-4")
    assert row["route"] == "specialist_ethics_and_clinical_review"


def test_guard_boundaries():
    assert guard("forced enhancement and eugenics")['decision']=="block_and_redirect"
    assert guard("brain-computer interface research")['decision']=="qualified_specialist_and_ethics_review_required"
    assert guard("build a reversible memory portability experiment")['decision']=="allow_reversible_humanbecoming_planning"


def test_output_and_static_audit(tmp_path):
    report=analyze_file(SAMPLE,tmp_path)
    assert report["system"]=="DIKWP HumanBecoming Evolution OS"
    required={
        "humanbecoming_report.json","dikwp_humanbecoming_ledger.json","life_morphospace.csv",
        "constitutive_substitutable_ledger.csv","constraint_closure_map.json",
        "rule_rewrite_opportunities.csv","identity_continuity_stress_test.md",
        "evolution_experiment_portfolio.csv","action_tickets.csv","human_definition_statement.md",
        "evolutionary_covenant.md",
    }
    assert required.issubset({p.name for p in tmp_path.iterdir()})
    assert audit(ROOT/"src")["pass"] is True
