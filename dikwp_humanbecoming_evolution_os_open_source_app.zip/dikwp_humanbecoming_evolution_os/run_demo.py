from pathlib import Path
import json
from dikwp_humanbecoming.analyzer import analyze_file

ROOT = Path(__file__).resolve().parent
report = analyze_file(ROOT / 'examples' / 'sample_humanbecoming_case.json', ROOT / 'outputs' / 'demo')
print(json.dumps({
    'system': report['system'],
    'route': report['route'],
    'human_becoming_index': report['metrics']['human_becoming_index'],
    'continuity_with_change_score': report['metrics']['continuity_with_change_score'],
    'open_ended_evolution_score': report['metrics']['open_ended_evolution_score'],
}, ensure_ascii=False, indent=2))
